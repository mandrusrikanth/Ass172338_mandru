package com.stream;

public class Trader {
	String name;
	String city;
	public Trader(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}
	public String getName() {
		return name;
	}
	public String getCity() {
		return city;
	}
	public Object getValue() {
		// TODO Auto-generated method stub
		return null;
	}
	public int getYear() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
