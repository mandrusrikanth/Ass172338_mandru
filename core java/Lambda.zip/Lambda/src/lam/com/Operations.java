package lam.com;

public interface Operations {
	
		int operations(int a,int b);
	}


