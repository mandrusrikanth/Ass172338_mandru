package lam.com;
@FunctionalInterface
public interface Order {
	void order(int price);

}
